# Pyramid Graphics & Printing Hub — Custom Website

## Quick setup
1. Open `script.js`.
2. Replace `234XXXXXXXXXX` with your real WhatsApp number.
3. Open `index.html` in a browser to preview the website.

## Before publishing
Replace:
- Business address
- Opening hours
- Portfolio sample cards with your actual work

The website uses quotation-based pricing (no fixed price list) and does not list binding or lamination.

## Free publishing
This website is static HTML/CSS/JavaScript, so it can be published free on GitHub Pages, Netlify, or Cloudflare Pages.

The site is mobile responsive and includes a WhatsApp order form.
